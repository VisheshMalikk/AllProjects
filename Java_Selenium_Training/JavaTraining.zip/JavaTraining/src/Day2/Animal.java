package Day2;

interface Animal {
	
	 public void eating(); // interface method (does not have a body)
	  public void sleeping(); // interface method (does not have a body)

}
