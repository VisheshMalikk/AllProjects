package Day2;

public class ArrayListInJava {

	public static void main(String[] args) {
		
		
		

	}

}
