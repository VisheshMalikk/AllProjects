package Day2;

public class Inheritance extends ArrayBasics { // This is the Child/Sub Class
	
	public static void main(String[] args) {
		
		Inheritance inherit = new Inheritance();
		inherit.showMyName();

	}

}
