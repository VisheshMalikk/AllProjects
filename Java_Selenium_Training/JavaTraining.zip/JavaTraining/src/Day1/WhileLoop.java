package Day1;

public class WhileLoop {

	public static void main(String[] args) {
		
		// while loop
		int i = 0;
		while (i < 5) {
		  System.out.println(i);
		  i++;
		}
		
		// do while loop
		System.out.println(" ----------- do while Loop --------------- ");
		
		int j = 0;
		do {
		  System.out.println(j);
		  j++;
		} while (j < 5);

	}

}
