package Day1;

public class ClassConcept {
	// defining fields
	// field or data member or instance variable
	int id = 10;
	String name = "Coforge";
	// creating main method inside the ClassConcept class
	public static void main(String[] args) {
		// Creating an object or instance
		ClassConcept classConcept = new ClassConcept();// creating an object of this class
		// Printing values of the object
		System.out.println(classConcept.id);// accessing member through reference variable
		System.out.println(classConcept.name);
	}
	
	
	
}


