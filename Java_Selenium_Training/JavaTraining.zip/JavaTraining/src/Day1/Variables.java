package Day1;

public class Variables {
	
	public static void main(String[] args) {
		
		int age = 3; // Integer DataType
		String name = "Coforge"; // String DataType
		char firstLetterOfName = 'C'; // Character DataType
		boolean bol = true; // Boolean DataType
		float myFloatNum = 5.99f;    // Floating point number
		
		System.out.println("First letter of my name is : " + firstLetterOfName);
		System.out.println("My name is " + name + " and now I am " + age + " years old ... !!");
		System.out.println("My boolean value is : " + bol);
		System.out.println("Floating Number is : " + myFloatNum);

	}

}
