package Day1;

public class StaticAndNonStaticVariables {

	static int a = 100; // static keyword
	static int b = 200; // Non Static keyword
	
	public static void main(String[] args) {
		// Creating the object of the class
		//StaticAndNonStaticVariables obj = new StaticAndNonStaticVariables();
		System.out.println("Sum is : " + sum(a,b));

	}
	
	public static int sum (int firstNum, int secondNum) {
		return firstNum + secondNum;
	}

}
