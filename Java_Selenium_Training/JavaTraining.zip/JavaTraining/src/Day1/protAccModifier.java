package Day1;

public class protAccModifier {
	protected String fname = "Vishesh";
	protected String lname = "Malik";
	protected String email = "VMalik@doe.com";
	protected int age = 27;
}
