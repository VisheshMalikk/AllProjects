package Day1;

public class ForEachLoop {

	public static void main(String[] args) {
		
		// For Each Loop
		String[] projects = {"Aflac", "Offcom", "PostOffice"}; // Array initialization
		for (String i : projects) {
		  System.out.println(i.toUpperCase());
		}
		
	}

}
