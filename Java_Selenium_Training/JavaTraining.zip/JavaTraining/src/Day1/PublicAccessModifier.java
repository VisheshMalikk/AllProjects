package Day1;

import Vishesh.pubAccModifier;

public class PublicAccessModifier {

	public static void main(String[] args) {
		pubAccModifier pub = new pubAccModifier();
		System.out.println(pub.fname);
		System.out.println(pub.lname);
		System.out.println(pub.email);
		System.out.println(pub.age);
	}

}
