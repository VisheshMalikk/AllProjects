package Day1;

public class LocalGlobalVariable {
	
	static int a =10;
	int b=5;
	public static void main(String[] args) {
		LocalGlobalVariable lv = new LocalGlobalVariable();
		LocalGlobalVariable lv2 = new LocalGlobalVariable();
		System.out.println(lv.add()); // Calling function here
		//System.out.println(lv.sub()); // Calling function here
	}
	
	// Local Variables
	public int add() {
		int x = 4; // Here ‘x’ is a local Variable
		return x;
	}
	// Global Variables
	public int sub(){
	return a-b; // Here a and b are global variables
	}

}
