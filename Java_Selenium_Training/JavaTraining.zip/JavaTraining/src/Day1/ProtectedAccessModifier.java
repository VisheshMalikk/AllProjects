package Day1;

class ProtectedAccessModifier extends protAccModifier {
	public static void main(String[] args) {
		ProtectedAccessModifier myObj = new ProtectedAccessModifier();
		System.out.println("Name: " + myObj.fname + " " + myObj.lname);
		System.out.println("Email: " + myObj.email);
		System.out.println("Age: " + myObj.age);
	}
}