package Vishesh;

public class SuperKeywordSuperClass { // Superclass (parent)

	String color = "White";

	// COnstructor
	public SuperKeywordSuperClass() {
		System.out.println("I am a constructor from Super class");
	}

	public void eat() {
		System.out.println("I am eating from Super Class");
	}

}
