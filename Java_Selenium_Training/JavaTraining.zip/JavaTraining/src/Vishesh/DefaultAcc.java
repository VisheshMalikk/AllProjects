package Vishesh;

public class DefaultAcc {

	public static void main(String[] args) {
		
		DefaultAccessModifiers show = new DefaultAccessModifiers(); // complile time error
		show.message();
	}

}
