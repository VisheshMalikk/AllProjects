package Vishesh;

public class pubAccModifier {

	public String fname = "Vishesh";
	public String lname = "Malik";
	public String email = "VisheshMalik@doe.com";
	public int age = 28;

}
